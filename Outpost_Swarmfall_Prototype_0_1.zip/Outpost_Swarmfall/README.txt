OUTPOST: SWARMFALL — Prototype 0.1

WHAT'S INCLUDED
- Mobile-first sci-fi idle game interface
- Automatic mineral and gas production
- Buildings, unit recruitment, research upgrades
- Periodic swarm threat, manual raids and rewards
- Objectives, local save, capped offline production
- PWA manifest and service worker for installable hosting

QUICK START
1. Unzip this folder.
2. Open index.html in a modern browser to play the prototype.
3. Progress is saved in that browser on that device.

INSTALL ON IPHONE / ANDROID
For the installable app experience, host the contents of this folder on an HTTPS static host (for example GitHub Pages or Netlify).
- iPhone: open the hosted URL in Safari, tap Share, then Add to Home Screen.
- Android: open the hosted URL in Chrome and choose Install app / Add to Home screen.

IMPORTANT
This is a playable web prototype, not yet a signed native iOS/Android app. Native store release would require a wrapper/build process, testing, and developer accounts. Save data is local to the browser/device and is not synced between devices.
